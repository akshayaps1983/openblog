from django.shortcuts import render,redirect
from django.urls import reverse_lazy
from django.http import HttpResponse
from django.views.generic import View,TemplateView,CreateView,FormView,UpdateView,DeleteView
from .forms import ProfileForm,CPassForm,BlogForm,CommentForm
from account.models import UserProfile,Blogs,comments
from django.contrib import messages
from django.contrib.auth import authenticate,logout
# Create your views here.

# class userView(TemplateView):
#     template_name="userhome.html"
class userView(CreateView):
    form_class=BlogForm
    model=Blogs
    template_name="userhome.html"
    success_url=reverse_lazy("uh")
    def form_valid(self, form):
        form.instance.user=self.request.user
        self.object=form.save()
        messages.success(self.request,"Blog Posted!!")
        return super().form_valid(form)
    def get_context_data(self, **kwargs):
        context=super().get_context_data(**kwargs)
        context["data"]=Blogs.objects.all().order_by("-date")
        context["cform"]=CommentForm()
        context["comments"]=comments.objects.all()
        print(context["data"])
        return context
       

class ProfileView(TemplateView):
    template_name="profile.html"

class CPassword(FormView):
    template_name="cpass.html"
    form_class=CPassForm
    def post(self,request,*args,**kwargs):
        form=self.form_class(data=request.POST)
        if form.is_valid():
            old=form.cleaned_data.get("old_pass")
            new=form.cleaned_data.get("new_pass")
            cnf=form.cleaned_data.get("cnf_pass")
            user=authenticate(request,username=request.user.username,password=old)
            if user:
                if new==cnf:
                    #user.password=new
                    #user.save()
                    user.set_password(new)
                    user.save()
                    logout(request)
                    messages.success(request,"password changed")
                    return redirect("log")
                else:
                    messages.error(request,"Password mismatch")
                    return redirect("cpass")
            else:
                messages.error(request,"old password entered is incorrect!!!")
                return redirect("cpass")


class AddProfile(CreateView):
    template_name="addprofile.html"
    form_class=ProfileForm
    model=UserProfile
    success_url=reverse_lazy("prof")
    def form_valid(self,form):
        form.instance.user=self.request.user
        self.object=form.save()
        messages.success(self.request,"profile added!!")
        return super().form_valid(form)

    # def post(self,request,*args,**kwargs):
    #     form_data=self.form_class(data=request.POST,files=request.FILES)
    #     if form_data.is_valid():
    #         form_data.instance.user=request.user
    #         form_data.save()
    #         return redirect("prof")
    #     else:
    #         return render(request,"addprofile.html",{"form":form_data})
class EditProfile(UpdateView):
    form_class=ProfileForm
    model=UserProfile
    success_url=reverse_lazy("pro")
    template_name="editprofile.html"
    pk_url_kwargs="pk"
    def form_valid(self, form):
        messages.success(self.request,"profile updated")
        self.object=form.save()
        return super().form_valid(form)
    # def get(self,request,*args,**kwargs):
    #     pid=kwargs.get("pid")
    #     p=UserProfile.objects.get(id=pid)
    #     f=ProfileForm(instance=p)
    #     return render(request,"editprofile.html",{"form":f})
    # def post(self,request,*args,**kwargs):
    #     pid=kwargs.get("pid")
    #     p=UserProfile.objects.get(id=pid)
    #     form_data=ProfileForm(data=request.POST,files=request.FILES,instance=p)
    #     if form_data.is_valid():
    #         form_data.save()
    #         messages.success(request,"profile updated")
        #    return redirect("prof")
       # else:
         #   return render(request,"editprofile.html",{"form":form_data})
class AddBlog(CreateView):
    form_class=BlogForm
    model=Blogs
    template_name="userhome.html"
    success_url=reverse_lazy("uh")
class MyBlogView(TemplateView):
    template_name="myblogs.html"
    def get_context_data(self, **kwargs): 
        context=super().get_context_data(**kwargs)
        context["data"]=Blogs.objects.filter(user=self.request.user).order_by("-date")
        return context
def commentadd(request,*args,**kwargs):
    if request.method=="POST":
        bid=kwargs.get("bid")
        blog=Blogs.objects.get(id=bid)
        cmnt=request.POST.get("comment")
        user=request.user
        comments.objects.create(comment=cmnt,user=user,blog=blog)
        messages.success(request,"comment submitted!!")
        return redirect("uh")
def addlike(request,*args,**kwargs):
    bid=kwargs.get("id")
    blog=Blogs.objects.get(id=bid)
    blog.liked_by.add(request.user)
    blog.save()
    return redirect("uh")
class DeleteBlog(DeleteView):
   model=Blogs
   success_url=reverse_lazy("myblog")
   template_name="deleteblog.html"

class EditBlog(UpdateView):
    form_class=BlogForm
    model=Blogs
    success_url=reverse_lazy("myblog")
    template_name="editBlog.html"
    pk_url_kwargs="pk"
    def form_valid(self, form):
        messages.success(self.request,"Blog updated")
        self.object=form.save()
        return super().form_valid(form)
    


    



