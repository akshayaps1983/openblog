from django.urls import path
from .views import *


urlpatterns = [
    path('userhome/',userView.as_view(),name="uh"),
    path('profile/',ProfileView.as_view(),name="prof"),
    path('addprofile/',AddProfile.as_view(),name="addpro"),
    path('cpass/',CPassword.as_view(),name="change"),
    path('blog/',MyBlogView.as_view(),name="myblog"),
    path('deleteb/<int:pk>',DeleteBlog.as_view(),name="deletep"),
    path('epro/<int:pk>',EditProfile.as_view(),name="editp"),
    path('eblog/<int:pk>',EditBlog.as_view(),name="editb"),
    path('addc/<int:bid>',commentadd,name="cmnt"),
    path('addl/<int:id>',addlike,name="addl")



    

    
]
